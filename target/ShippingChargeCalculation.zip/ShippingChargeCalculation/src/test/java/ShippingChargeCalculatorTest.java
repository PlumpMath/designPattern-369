import com.flipkart.covenant.shippingCharge.ShippingChargeCalculator;
import com.flipkart.covenant.shippingCharge.model.Listing;
import com.flipkart.covenant.shippingCharge.model.ShippingChargeCalculatorBean;
import com.flipkart.covenant.shippingCharge.model.ShippingRate;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import junit.framework.TestCase;

import javax.annotation.concurrent.Immutable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by manish.sharan on 15/01/15.
 */
public class ShippingChargeCalculatorTest extends TestCase{

    ShippingChargeCalculator shippingChargeCalculator;
    public static final String listing1 = "LSTSNDDZZNZ5YAEGTD3N58O0N";
    public static final String listing2 = "LSTSNDDZZNZ5YAEGTD3N58O0P";

    public void setUp(){
        shippingChargeCalculator= new ShippingChargeCalculator();
    }

    //test seller and wsr Regular
    public void testPopulateShippingCharges(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("150"), new BigDecimal("250")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("REGULAR");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20002", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("0"),listing2,new BigDecimal("250")));
        assertEqualsMap(expected,actual);
    }
    //test premium non-F1
    public void testPopulateShippingCharges1(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("premium");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20002", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("140"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test premium F1
    public void testPopulateShippingCharges2(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(true);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("premium");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20002", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("70"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test express F1
    public void testPopulateShippingCharges3(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(true);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("express");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20002", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("0"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test express non-F1
    public void testPopulateShippingCharges4(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("express");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20002", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("90"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test express non-F1 free ndd on mobile below 1000
    public void testPopulateShippingCharges5(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("express");
        shippingChargeCalculatorBean.setSalesChannel("AndroidApp");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20079", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("90"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test regular non-F1 non books
    public void testPopulateShippingCharges6(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("regular");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("399.0"),1, "wsr", "FBF", false, false, "20079", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("40"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test regular non-F1 non-books
    public void testPopulateShippingCharges7(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("regular");
        shippingChargeCalculatorBean.setSalesChannel("website");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("1399.0"),1, "wsr", "FBF", false, false, "20079", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("0"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    //test express non-F1 free ndd on mobile above 1000
    public void testPopulateShippingCharges8(){
        Map<String,ShippingRate> myMap = new HashMap<String, ShippingRate>();
        myMap.put(listing1, new ShippingRate(new BigDecimal("0"), new BigDecimal("0"), new BigDecimal("0")));
        myMap.put(listing2, new ShippingRate(new BigDecimal("50"), new BigDecimal("50"), new BigDecimal("50")));

        ShippingChargeCalculatorBean shippingChargeCalculatorBean = new ShippingChargeCalculatorBean();
        shippingChargeCalculatorBean.setIsFlipkartFirst(false);
        shippingChargeCalculatorBean.setIsOrder(false);
        shippingChargeCalculatorBean.setTier("express");
        shippingChargeCalculatorBean.setSalesChannel("iOSApp");
        shippingChargeCalculatorBean.setIsFreebie(false);

        Set<Listing> mySet = new HashSet<Listing>();
        mySet.add(new Listing(listing1,new BigDecimal("1399.0"),1, "wsr", "FBF", false, false, "20079", "inter_zone",myMap));
        mySet.add(new Listing(listing2,new BigDecimal("399.0"),1, "sabe4erbd", "NON_FBF", false, false, "20079", "inter_zone",myMap));
        shippingChargeCalculatorBean.setListings(mySet);

        Map<String,BigDecimal> actual = shippingChargeCalculator.populateShippingCharges(shippingChargeCalculatorBean);
        Map<String,BigDecimal> expected = Maps.newHashMap(ImmutableMap.of(listing1,new BigDecimal("0"),listing2,new BigDecimal("50")));
        assertEqualsMap(expected,actual);
    }

    public void assertEqualsMap(Map<String,BigDecimal> expected, Map<String,BigDecimal> actual){
        assertEquals(expected.size(), actual.size());
        for(Map.Entry<String,BigDecimal> value:expected.entrySet()) {
            BigDecimal actualValue = actual.get(value.getKey());
            assertNotNull(actualValue);
            assertEquals(value.getValue(), actualValue);
        }
    }
}
