package com.flipkart.covenant.shippingCharge.bootstrap;

import com.flipkart.covenant.shippingCharge.config.PricingConfig;
import com.flipkart.covenant.shippingCharge.config.ShippingChargeConfiguration;
import com.flipkart.covenant.shippingCharge.helper.PricingConfigHelper;
import com.google.inject.AbstractModule;
import com.google.inject.Scopes;

/**
 * Created by manish.sharan on 13/01/15.
 */
public class ShippingChargeModule extends AbstractModule {

    @Override
    public void configure() {
        bind(PricingConfig.class).in(Scopes.SINGLETON);
        bind(ShippingChargeConfiguration.class).in(Scopes.SINGLETON);
        bind(PricingConfigHelper.class).in(Scopes.SINGLETON);
    }
}
