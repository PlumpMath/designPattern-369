package com.flipkart.covenant.shippingCharge.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.flipkart.covenant.shippingCharge.model.SalesChannel;
import com.yammer.dropwizard.json.JsonSnakeCase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by manish.sharan on 13/01/15.
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonSnakeCase
public class PricingAttributes {
    @JsonProperty
    private BigDecimal baseShippingCharge;
    @JsonProperty
    private Map<BigDecimal, BigDecimal> globalAspShippingMap;
    @JsonProperty
    private Map<String, Map<BigDecimal, BigDecimal>> categoryAspToPriceMap;
    @JsonProperty
    private Map<SalesChannel, Map<BigDecimal, BigDecimal>> salesChannelAspToPriceMap;
    @JsonProperty
    private Map<String, BigDecimal> shippingChargesPerListing;
    @JsonProperty
    private boolean globalAspApplicable;
}
