package com.flipkart.covenant.shippingCharge.model;

/**
 * Created by manish.sharan on 10/01/15.
 */
public enum Tier {

    REGULAR, EXPRESS, PREMIUM;

    public static boolean isRegularTier(Tier tier){
        return tier == Tier.REGULAR;
    }
}
