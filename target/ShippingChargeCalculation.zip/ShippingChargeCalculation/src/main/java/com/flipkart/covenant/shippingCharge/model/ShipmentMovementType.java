package com.flipkart.covenant.shippingCharge.model;

/**
 * Created by manish.sharan on 10/01/15.
 */
public enum ShipmentMovementType {
    intra_city, intra_zone, inter_zone;
}
