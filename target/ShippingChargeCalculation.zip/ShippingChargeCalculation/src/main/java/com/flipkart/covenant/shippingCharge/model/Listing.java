package com.flipkart.covenant.shippingCharge.model;

/**
 * Created by manish.sharan on 10/01/15.
 */

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;

@Getter
@Setter
public class Listing {
    private final String listingId;
    private BigDecimal sellingPrice;
    private Integer quantity;
    private String sellerId;
    private ServiceProfile serviceProfile;
    private Boolean isFreebie;
    private Boolean isDigital;
    private String category;
    private ShipmentMovementType shipmentMovementType;
    private Map<String,ShippingRate> shippingRate;

    public Listing(String listingId, BigDecimal sellingPrice, Integer quantity, String sellerId, String serviceProfile,
                  Boolean isFreebie, Boolean isDigital, String category, String shipmentMovementType, Map<String,ShippingRate> shippingRate ){
        this.listingId = listingId;
        this.sellingPrice = sellingPrice;
        this.quantity = quantity;
        this.sellerId = sellerId;
        this.serviceProfile = ServiceProfile.valueOf(serviceProfile.toUpperCase());
        this.isFreebie = isFreebie;
        this.isDigital = isDigital;
        this.category = category;
        this.shipmentMovementType = ShipmentMovementType.valueOf(shipmentMovementType.toLowerCase());
        this.shippingRate = shippingRate;
    }

    public Boolean belongsToWSR() {
        return (sellerId != null && sellerId.equalsIgnoreCase("wsr"));
    }

    @Override
    public String toString() {
        return listingId ;
    }

    public boolean isFA(){
        return ( belongsToWSR() || (serviceProfile == ServiceProfile.FBF));
    }

    public boolean isFreeRegularShipping(PricingDetails pricingDetails){
        return this.isFA() && this.getSellingPrice().compareTo(pricingDetails.getWsrPricingThreshold()) >=0;
    }

    public boolean isInternalSeller(){
        return this.sellerId != null && (belongsToWSR() || this.serviceProfile == ServiceProfile.FBF);
    }

    public Boolean isInvalid(){
        if(this.getListingId()==null||this.getSellingPrice()==null||this.getQuantity()==null||this.sellerId==null||this.getIsFreebie()==null||this.getIsDigital()==null
            ||this.getCategory()==null|| invalidShipmentMovementType(this.getShipmentMovementType())|| invalidServiceProfile(this.getServiceProfile())
                || invalidShippingRates(this.getShippingRate())){
            return true;
        }
        return false;
    }

    private Boolean invalidShipmentMovementType(ShipmentMovementType shipmentMovementType){
        if(shipmentMovementType!=null && Arrays.asList(ShipmentMovementType.values()).contains(shipmentMovementType)) return false;
        return true;
    }

    private Boolean invalidServiceProfile(ServiceProfile serviceProfile){
        if(serviceProfile!=null && Arrays.asList(ServiceProfile.values()).contains(serviceProfile)) return false;
        return true;
    }

    private Boolean invalidShippingRates(Map<String, ShippingRate> shippingRateMap){
        for(Map.Entry<String,ShippingRate> shippingRateEntry:shippingRateMap.entrySet()){
            if(shippingRateEntry.getKey()==null) return true;
            if(shippingRateEntry.getValue().isInvalid()) return true;
        }
        return false;
    }
}

