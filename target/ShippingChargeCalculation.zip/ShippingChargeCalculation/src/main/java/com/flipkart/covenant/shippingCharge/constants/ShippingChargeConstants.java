package com.flipkart.covenant.shippingCharge.constants;

import com.flipkart.covenant.shippingCharge.model.Tier;

/**
 * Created by manish.sharan on 10/01/15.
 */
public class ShippingChargeConstants {

    public static Boolean usePoller = false;

    public static class F1ShippingCharges{
        public static final String REGULAR_F1_SHIPPING_CHARGE = null;
        public static final String EXPRESS_F1_SHIPPING_CHARGE = null;
        public static final String PREMIUM_F1_SHIPPING_CHARGE = null;

        public static String getF1ShippingCharges(Tier tier){
            switch (tier) {
                case REGULAR: return REGULAR_F1_SHIPPING_CHARGE;
                case EXPRESS: return EXPRESS_F1_SHIPPING_CHARGE;
                case PREMIUM: return PREMIUM_F1_SHIPPING_CHARGE;
                default: return null;
            }
        }
    }

    public static class ShippingCharge{
        public static final String REGULAR_SHIPPING_CHARGE = null;
        public static final String EXPRESS_SHIPPING_CHARGE = "90";
        public static final String PREMIUM_SHIPPING_CHARGE = "140";

        public static String getShippingCharge(Tier tier){
            switch (tier) {
                case REGULAR: return REGULAR_SHIPPING_CHARGE;
                case EXPRESS: return EXPRESS_SHIPPING_CHARGE;
                case PREMIUM: return PREMIUM_SHIPPING_CHARGE;
                default: return null;
            }
        }
    }

    public static class WsrPricingThreshold{
        public static final String WSR_PRICING_THRESHOLD = null;
    }

    public static final String PE_PRICING_CONFIG_URL = "http://flo-covenant-app-16.nm.flipkart.com:30303/config/pricing";
    public static final String PE_F1_SHIPPING_CHARGE_URL = "http://localhost:30303/config/f1ShippingCharge";
    public static final String PE_CATEGORY_PATH_URL = "http://localhost:30303/category/getCategoryPath/";
}
