package com.flipkart.covenant.shippingCharge.model;

/**
 * Created by manish.sharan on 10/01/15.
 */
public enum SalesChannel {
    website, mobile, MobileSite, AndroidApp, iOSApp, WindowsApp;
}
