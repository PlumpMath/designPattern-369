package com.flipkart.covenant.shippingCharge.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.flipkart.covenant.shippingCharge.model.DynamicPricingAttributes;
import com.flipkart.covenant.shippingCharge.model.Tier;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by manish.sharan on 13/01/15.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PricingConfig {
    @JsonProperty("pricing_attributes")
    Map<Tier,DynamicPricingAttributes> pricingAttributes;
    @JsonProperty("wsr_pricing_threshold")
    BigDecimal wsrPricingThreshold;

}
