package com.flipkart.covenant.shippingCharge.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by manish.sharan on 10/01/15.
 */
@Setter
@Getter
@AllArgsConstructor
public class ShippingDetails {
    private Map<Tier,BigDecimal> premiumCustomerPrice;

    private PricingDetails pricingDetails;

    public BigDecimal getShippingCharge(Listing listing, Tier tier, ShipmentMovementType shipmentMovementType, Map<String,ShippingRate> shippingRates, SalesChannel salesChannel, boolean isFlipkartFirst, boolean isFreeShipping, boolean isFreebie){
        BigDecimal shippingCharges = listing.isInternalSeller() ? getShippingChargeForFA(listing,tier, salesChannel,  isFlipkartFirst, isFreeShipping, isFreebie):
                getShippingChargeForNonFA(listing,shippingRates, shipmentMovementType, isFreebie);
        return shippingCharges;
    }

    private BigDecimal getShippingChargeForNonFA(Listing listing, Map<String,ShippingRate> shippingRates, ShipmentMovementType shipmentMovementType, boolean isFreebie) {
        BigDecimal shippingCharge = BigDecimal.ZERO;
        shippingCharge = shippingCharge.add((listing.getSellingPrice().compareTo(BigDecimal.ZERO) == 0 || isFreebie) ? BigDecimal.ZERO : shippingRates.get(listing.getListingId()).get(shipmentMovementType));
        return  shippingCharge;
    }

    private BigDecimal getShippingChargeForFA(Listing listing, Tier tier, SalesChannel salesChannel, boolean isFlipkartFirst, boolean isFreeShipping, boolean isFreebie) {
        BigDecimal shippingCharge = BigDecimal.ZERO;
        isFreeShipping &= Tier.isRegularTier(tier);
        boolean isFreeRegularShipping = listing.isFreeRegularShipping(pricingDetails) && Tier.isRegularTier(tier);
        shippingCharge = shippingCharge.add((isFreebie || listing.getSellingPrice().equals(BigDecimal.ZERO) || isFreeShipping || isFreeRegularShipping) ? BigDecimal.ZERO : (isFlipkartFirst ? premiumCustomerPrice.get(tier) :
                pricingDetails.getShippingPrice(listing.getCategory(), listing.getSellingPrice(), listing.getListingId(), tier , salesChannel)));
        return shippingCharge;
    }
}
