package com.flipkart.covenant.shippingCharge.config;

import com.flipkart.covenant.shippingCharge.model.Tier;
import com.google.inject.Inject;
import com.google.inject.Singleton;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by manish.sharan on 13/01/15.
 */
@Setter
@Singleton
@Getter
@NoArgsConstructor
public class ShippingChargeConfiguration{

    PricingConfig pricingConfig = new PricingConfig();
    Map<Tier,BigDecimal> f1ShippingCharges = new HashMap<Tier, BigDecimal>();
    Map<String,List<String>> categoryIdList = new HashMap<String, List<String>>();

    @Inject
    public ShippingChargeConfiguration(PricingConfig pricingConfig){
        this.pricingConfig = pricingConfig;
    }

    public Boolean getCommonPriceForAll(Tier tier){
        return pricingConfig.getPricingAttributes().get(tier).isGlobalAspApplicable();
    }

    public BigDecimal getBaseShippingCharge(Tier tier){
        return pricingConfig.getPricingAttributes().get(tier).getBaseShippingCharge();
    }

    public Map<BigDecimal, BigDecimal> getGlobalAspShippingMap(Tier tier){
        return pricingConfig.getPricingAttributes().get(tier).getGlobalAspShippingMap();
    }

    public Map<String, Map<BigDecimal, BigDecimal>>getCategoryAspPricingMap(Tier tier){
        return pricingConfig.getPricingAttributes().get(tier).getCategoryAspToPriceMap();
    }

    public BigDecimal getWsrShippingPriceThreshold(){
        return pricingConfig.getWsrPricingThreshold();
    }

    public Map<String, Map<BigDecimal, BigDecimal>> getSalesChannelAspPricingMap(Tier tier){
        return pricingConfig.getPricingAttributes().get(tier).getSalesChannelAspToPriceMap();
    }

    public Map<String,BigDecimal> getShippingChargesPerListing(Tier tier){
        return pricingConfig.getPricingAttributes().get(tier).getShippingChargesPerListing();
    }

    public BigDecimal getF1ShippingCharge(Tier tier){
        if(f1ShippingCharges.containsKey(tier)) return f1ShippingCharges.get(tier);
        return null;
    }
}
