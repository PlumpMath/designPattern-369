package com.flipkart.covenant.shippingCharge.model;

import com.flipkart.covenant.shippingCharge.exception.InadequateInformationException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * Created by manish.sharan on 11/01/15.
 */
@Getter
@Setter
@NoArgsConstructor
public class ShippingChargeCalculatorBean{
    private Set<Listing> listings;
    private Boolean isOrder;
    private String tier;
    private String salesChannel;
    private Boolean isFlipkartFirst;
    private Boolean isFreebie;

    public Boolean validate() throws InadequateInformationException{
        if(this.getIsOrder()==null|| invalidTier(this.getTier())==null|| invalidSalesChannel(this.getSalesChannel())==null||this.isFlipkartFirst==null||this.isFreebie==null
                ||invalidListings(this.getListings())) {
            throw new InadequateInformationException("Missing/Wrong information");
        }
        return true;
    }

    private Boolean invalidListings(Set<Listing> listings){
        for(Listing listing:listings){
            if(listing.isInvalid()==true) return true;
        }
        return false;
    }

    private Boolean invalidTier(String tier){
        if(tier!=null && (Arrays.asList(Tier.values()).contains(Tier.valueOf(tier.toUpperCase())))) return false;
        return true;
    }

    private Boolean invalidSalesChannel(String salesChannel){
        if(salesChannel!=null && (Arrays.asList(SalesChannel.values()).contains(SalesChannel.valueOf(salesChannel.toString())))) return false;
        return true;
    }
}
