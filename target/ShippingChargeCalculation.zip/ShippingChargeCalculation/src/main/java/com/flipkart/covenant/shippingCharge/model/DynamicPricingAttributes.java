package com.flipkart.covenant.shippingCharge.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by manish.sharan on 13/01/15.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DynamicPricingAttributes {
    @JsonProperty("globalAspApplicable")
    private boolean isGlobalAspApplicable;
    @JsonProperty
    private BigDecimal baseShippingCharge;
    @JsonProperty
    private Map<BigDecimal, BigDecimal> globalAspShippingMap;
    @JsonProperty
    private Map<String, Map<BigDecimal, BigDecimal>> categoryAspToPriceMap;
    @JsonProperty
    private Map<String, Map<BigDecimal, BigDecimal>> salesChannelAspToPriceMap;
    @JsonProperty
    private Map<String, BigDecimal> shippingChargesPerListing;
}