package com.flipkart.covenant.shippingCharge;

import com.flipkart.covenant.shippingCharge.bootstrap.Bootstrapper;
import com.flipkart.covenant.shippingCharge.bootstrap.Initializer;
import com.flipkart.covenant.shippingCharge.constants.ShippingChargeConstants;
import com.flipkart.covenant.shippingCharge.exception.InadequateInformationException;
import com.flipkart.covenant.shippingCharge.helper.PricingConfigHelper;
import com.flipkart.covenant.shippingCharge.model.*;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by manish.sharan on 10/01/15.
 */
public class ShippingChargeCalculator {

    static {
        Bootstrapper.start();
    }

    public Map<String, BigDecimal> populateShippingCharges(ShippingChargeCalculatorBean shippingChargeCalculatorBean) {
        Map<String, BigDecimal> listingShippingChargeMap = new HashMap<String, BigDecimal>();
        try {
            if (shippingChargeCalculatorBean.validate()) {
                System.out.println("Inside populateShippingCharges");
                Set<Listing> listings = shippingChargeCalculatorBean.getListings();
                boolean isEligibleForFreeShipping = PricingConfigHelper.isFreeShipping(listings, shippingChargeCalculatorBean.getIsOrder());
                Map<Tier, BigDecimal> premiumCustPrice = PricingConfigHelper.getFlipkartFirstShippingCharges();
                ShippingDetails shippingDetails = new ShippingDetails(premiumCustPrice, PricingDetails.getPricingDetails());
                List<Listing> physicalListings = new ArrayList<Listing>();
                for (Listing listing : listings) {
                    if (!listing.getIsDigital()) {
                        physicalListings.add(listing);
                    }
                }
                for (Listing listing : physicalListings) {
                    ShipmentMovementType shipmentMovementType = listing.getShipmentMovementType() == null ? ShipmentMovementType.inter_zone : listing.getShipmentMovementType();
                    BigDecimal shippingCharge = shippingDetails.getShippingCharge(listing, Tier.valueOf(shippingChargeCalculatorBean.getTier().toUpperCase()),
                            shipmentMovementType, listing.getShippingRate(), SalesChannel.valueOf(shippingChargeCalculatorBean.getSalesChannel()),
                            shippingChargeCalculatorBean.getIsFlipkartFirst(), isEligibleForFreeShipping, listing.getIsFreebie());
                    listingShippingChargeMap.put(listing.getListingId(), (shippingCharge == null ? BigDecimal.ZERO : shippingCharge));
                }
            }
        } catch (InadequateInformationException e) {
            System.out.println(e.getCause());
        }
        return listingShippingChargeMap;
    }
}