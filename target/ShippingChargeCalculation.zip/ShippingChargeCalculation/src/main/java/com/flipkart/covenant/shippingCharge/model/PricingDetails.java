package com.flipkart.covenant.shippingCharge.model;

import com.flipkart.covenant.shippingCharge.bootstrap.Initializer;
import com.flipkart.covenant.shippingCharge.config.ShippingChargeConfiguration;
import com.flipkart.covenant.shippingCharge.constants.ShippingChargeConstants;
import com.flipkart.covenant.shippingCharge.helper.PricingConfigHelper;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by manish.sharan on 10/01/15.
 */
@Getter
@Setter
@AllArgsConstructor
public class PricingDetails {
    private Map<Tier, DynamicPricingAttributes> pricingAttributes;
    private BigDecimal wsrPricingThreshold;
    private ShippingChargeConfiguration shippingChargeConfiguration = Initializer.shippingChargeConfiguration;

    public static PricingDetails getPricingDetails(){
        if(!ShippingChargeConstants.usePoller){
            return PricingConfigHelper.getDefaultPricingMap();
        }
        return PricingConfigHelper.getNddAspPricingDetails();
    }

    public BigDecimal getShippingPrice(String category, BigDecimal sellingPrice, String listingId, Tier tier, SalesChannel salesChannel){
        DynamicPricingAttributes dynamicPricingAttributes = pricingAttributes != null ? pricingAttributes.get(tier) : null;
        if(dynamicPricingAttributes != null){
            return getPriceForTier(category, sellingPrice, listingId, dynamicPricingAttributes.getShippingChargesPerListing(), dynamicPricingAttributes.isGlobalAspApplicable(),
                    dynamicPricingAttributes.getCategoryAspToPriceMap(), dynamicPricingAttributes.getSalesChannelAspToPriceMap(), dynamicPricingAttributes.getGlobalAspShippingMap(), tier,
                    dynamicPricingAttributes.getBaseShippingCharge(), salesChannel);
        }else {
            return PricingConfigHelper.getDefaultPrice(tier);
        }
    }

    private BigDecimal getPriceForTier(String category, BigDecimal sellingPrice, String listingId,
                                       Map<String, BigDecimal> listingPrices, boolean globalAspApplicable,
                                       Map<String, Map<BigDecimal, BigDecimal>> categoryAspPricing, Map<String, Map<BigDecimal, BigDecimal>> salesChannelAspPricing, Map<BigDecimal, BigDecimal> globalAspPricing,
                                       Tier tier, BigDecimal baseShippingCharge, SalesChannel salesChannel){
        if(listingPrices != null && listingPrices.containsKey(listingId)) return listingPrices.get(listingId);
        Map<BigDecimal, BigDecimal> categoryPricings = getCategoryPriceMap(category, categoryAspPricing);
        Map<BigDecimal, BigDecimal> salesChannelPricings = (salesChannelAspPricing!=null && salesChannelAspPricing.containsKey(salesChannel.toString())) ? salesChannelAspPricing.get(salesChannel.toString()) : Maps.<BigDecimal, BigDecimal>newHashMap();
        Map<BigDecimal, BigDecimal> aspPricings = (globalAspApplicable && categoryAspPricing.isEmpty() ? globalAspPricing : categoryPricings);
        return getPrice(aspPricings, salesChannelPricings, sellingPrice, tier, baseShippingCharge);
    }

    private BigDecimal getPrice(Map<BigDecimal, BigDecimal> aspNddMap,Map<BigDecimal, BigDecimal> salesChannelMap, BigDecimal sellingPrice, Tier tier, BigDecimal baseShippingCharge){
        BigDecimal aspNddPrice = new BigDecimal(-1);
        if(aspNddMap != null && !aspNddMap.isEmpty()){
            List<BigDecimal> aspValues = new ArrayList<BigDecimal>(aspNddMap.keySet());
            Collections.sort(aspValues);
            for(BigDecimal aspValue : aspValues){
                if(aspValue.compareTo(sellingPrice) > 0) break;
                aspNddPrice = aspNddMap.get(aspValue);
            }
        }
        if(salesChannelMap != null && !salesChannelMap.isEmpty()){
            List<BigDecimal> aspValues = new ArrayList<BigDecimal>(salesChannelMap.keySet());
            Collections.sort(aspValues);
            for(BigDecimal aspValue : aspValues){
                if(aspValue.compareTo(sellingPrice) > 0) break;
                aspNddPrice = aspNddPrice.compareTo(new BigDecimal(-1))== 0 ? salesChannelMap.get(aspValue) : aspNddPrice.min(salesChannelMap.get(aspValue));
            }
        }
        return (aspNddPrice.compareTo(new BigDecimal(-1)) == 0 ? (baseShippingCharge != null ? baseShippingCharge : PricingConfigHelper.getDefaultPrice(tier)) : aspNddPrice);
    }

    private Map<BigDecimal, BigDecimal> getCategoryPriceMap(String categoryId, Map<String, Map<BigDecimal, BigDecimal>> categoryPriceMap){
        Map<BigDecimal, BigDecimal> aspNddMap = new HashMap<BigDecimal, BigDecimal>();
        if(shippingChargeConfiguration!=null) {
            Set<String> parentCategories = shippingChargeConfiguration.getCategoryIdList().keySet();
            for (String category : parentCategories) {
                if (shippingChargeConfiguration.getCategoryIdList().get(category).contains(categoryId)) {
                    aspNddMap = categoryPriceMap.get(category);
                    break;
                }
            }
        }
        return aspNddMap;
    }

}
