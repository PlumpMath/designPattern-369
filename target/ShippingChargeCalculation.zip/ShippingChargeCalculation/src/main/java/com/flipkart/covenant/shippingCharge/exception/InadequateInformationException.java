package com.flipkart.covenant.shippingCharge.exception;

/**
 * Created by manish.sharan on 11/01/15.
 */
public class InadequateInformationException extends Exception {

    public InadequateInformationException(Object missingAttribute){
        System.out.println(missingAttribute);
    }
}
