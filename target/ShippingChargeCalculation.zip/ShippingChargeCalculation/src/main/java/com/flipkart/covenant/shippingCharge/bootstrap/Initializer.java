package com.flipkart.covenant.shippingCharge.bootstrap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flipkart.covenant.shippingCharge.config.PricingConfig;
import com.flipkart.covenant.shippingCharge.config.ShippingChargeConfiguration;
import com.flipkart.covenant.shippingCharge.constants.ShippingChargeConstants;
import com.flipkart.covenant.shippingCharge.model.Tier;
import com.google.common.collect.Lists;
import com.google.inject.Guice;
import com.google.inject.Injector;
import lombok.Getter;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by manish.sharan on 13/01/15.
 */
@Getter
public class Initializer implements Runnable{

    HttpClient client;
    public static volatile ShippingChargeConfiguration shippingChargeConfiguration = new ShippingChargeConfiguration();

    @Override
    public void run() {
        while(true) {
            try {
                initialize();
                Thread.sleep(6000L);
                System.out.println("Woken up again");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void initialize(){
        System.out.println("Inside thread Initializer");
   //     doDIInjection();
        doPricingConfigInitialization();
        doF1ShippingChargeInitialization();
        doCategoryListInitialization();
        System.out.println("Initialized config class"+shippingChargeConfiguration.getPricingConfig().getWsrPricingThreshold()
                +":::"+shippingChargeConfiguration.getF1ShippingCharges()+"::::"+shippingChargeConfiguration.getCategoryIdList());
        ShippingChargeConstants.usePoller = true;
    }

    public void doDIInjection(){
        Injector injector = Guice.createInjector(new ShippingChargeModule());
        shippingChargeConfiguration = injector.getInstance(ShippingChargeConfiguration.class);
    }

    public void doPricingConfigInitialization() {
        String json = fireHTTPGetRequest(ShippingChargeConstants.PE_PRICING_CONFIG_URL);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            PricingConfig pricingConfig = objectMapper.readValue(json, PricingConfig.class);
            shippingChargeConfiguration.setPricingConfig(pricingConfig);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            shutdownHttpClient();
        }
    }

    public void doF1ShippingChargeInitialization() {
        String json = fireHTTPGetRequest(ShippingChargeConstants.PE_F1_SHIPPING_CHARGE_URL);
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<Tier,BigDecimal> f1ShippingChargeMap = objectMapper.readValue(json, Map.class);
            shippingChargeConfiguration.setF1ShippingCharges(f1ShippingChargeMap);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            shutdownHttpClient();
        }
    }

    public void doCategoryListInitialization(){
        Map<String,List<String>> categoryDescendendMap = new HashMap<String, List<String>>();
        List<String> configurationCategoryId = Lists.newArrayList();
        if(shippingChargeConfiguration.getPricingConfig()!=null) {
            for (Tier tier : Tier.values()) {
                Map<String, Map<BigDecimal, BigDecimal>> categoryPriceMap = shippingChargeConfiguration.getCategoryAspPricingMap(tier);
                for (Map.Entry<String, Map<BigDecimal, BigDecimal>> entry : categoryPriceMap.entrySet()) {
                    configurationCategoryId.add(entry.getKey());
                }
            }
            for (String categoryId : configurationCategoryId) {
                try {
                    String json = fireHTTPGetRequest(ShippingChargeConstants.PE_CATEGORY_PATH_URL+categoryId);
                    ObjectMapper objectMapper = new ObjectMapper();
                    List<String> categoryChildrenList = objectMapper.readValue(json, List.class);
                    categoryDescendendMap.put(categoryId, categoryChildrenList);
                } catch (IOException e) {
                    e.printStackTrace();
                }finally {
                    shutdownHttpClient();
                }
            }
        }
        shippingChargeConfiguration.setCategoryIdList(categoryDescendendMap);
    }

    public String fireHTTPGetRequest(String url){
        client = new DefaultHttpClient();
        String json=null;
        HttpGet getRequest = new HttpGet(url);
        getRequest.addHeader("accept", "application/json");
        HttpResponse response = null;
        try {
            response = client.execute(getRequest);
            if(response.getStatusLine().getStatusCode()!=200){
                throw new RuntimeException("Failed : HTTP error code : "+ response.getStatusLine().getStatusCode());
            }else {
                json = EntityUtils.toString(response.getEntity(), "UTF-8");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return json;
    }

    private void shutdownHttpClient() {
        client.getConnectionManager().shutdown();
    }
}
