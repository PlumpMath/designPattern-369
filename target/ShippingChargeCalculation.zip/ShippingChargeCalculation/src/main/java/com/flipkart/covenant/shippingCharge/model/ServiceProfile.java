package com.flipkart.covenant.shippingCharge.model;

/**
 * Created by manish.sharan on 10/01/15.
 */
public enum ServiceProfile {
        FBF, NON_FBF;
}
