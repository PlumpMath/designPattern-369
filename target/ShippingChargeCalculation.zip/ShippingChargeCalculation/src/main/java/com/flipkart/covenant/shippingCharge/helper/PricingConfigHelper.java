package com.flipkart.covenant.shippingCharge.helper;

import com.flipkart.covenant.shippingCharge.bootstrap.Initializer;
import com.flipkart.covenant.shippingCharge.config.ShippingChargeConfiguration;
import com.flipkart.covenant.shippingCharge.constants.ShippingChargeConstants;
import com.flipkart.covenant.shippingCharge.model.*;
import com.google.common.collect.Maps;
import com.google.inject.Inject;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;

/**
 * Created by manish.sharan on 10/01/15.
 */
public class PricingConfigHelper {

    private static volatile ShippingChargeConfiguration shippingChargeConfiguration = Initializer.shippingChargeConfiguration;

    public static Map<Tier,BigDecimal> getFlipkartFirstShippingCharges() {
        System.out.println("Inside getFlipkartFirstShippingCharges, Poller = "+ShippingChargeConstants.usePoller);
        if(!ShippingChargeConstants.usePoller) { return getDefaultF1ShippingCharges();}
        return getF1ShippingCharges();
    }

    public static boolean isFreeShipping(Set<Listing> listings,boolean isOrder){
        boolean freeRegularShipping = isOrder;
        if(freeRegularShipping){
            freeRegularShipping = freeRegularShipping && (getPossibleOrderPrice(listings,"wsr").compareTo(PricingDetails.getPricingDetails().getWsrPricingThreshold()) >= 0);
        }
        return freeRegularShipping;
    }

    public static BigDecimal getPossibleOrderPrice(Set<Listing> listings,String sellerId){
        BigDecimal orderPrice = BigDecimal.ZERO;
        for(Listing listing: listings) {
            if (!listing.getIsFreebie()) {
                if (listing.getSellerId().equalsIgnoreCase(sellerId) || listing.getServiceProfile() == ServiceProfile.FBF)
                    orderPrice = orderPrice.add(listing.getSellingPrice().multiply(BigDecimal.valueOf(listing.getQuantity())));
            }
        }
        return orderPrice;
    }

    public static PricingDetails getDefaultPricingMap(){
        return new PricingDetails(getDefaultPricingAttributes(),new BigDecimal(500),shippingChargeConfiguration);
    }

    public static Map<Tier, DynamicPricingAttributes> getDefaultPricingAttributes(){
        Map<BigDecimal, BigDecimal> nddAspPriceMap = Maps.newHashMap();
        Map<String, Map<BigDecimal, BigDecimal>> categoryNddAspPriceMap = Maps.newHashMap();
        Map<String, Map<BigDecimal, BigDecimal>> salesChannelAspPriceMap = Maps.newHashMap();

        Map<String, BigDecimal> customCharges = Maps.newHashMap();
        Map<Tier, DynamicPricingAttributes> dynamicPricingAttributesMap = Maps.newHashMap();
        for(Tier tier : Tier.values()){
            DynamicPricingAttributes dynamicPricingAttributes = new DynamicPricingAttributes(false, getDefaultPrice(tier), nddAspPriceMap, categoryNddAspPriceMap, salesChannelAspPriceMap,customCharges);
            dynamicPricingAttributesMap.put(tier, dynamicPricingAttributes);
        }
        return dynamicPricingAttributesMap;
    }

    public static BigDecimal getDefaultPrice(Tier tier){
        if(tier.equals(Tier.REGULAR)) return BigDecimal.valueOf(40);
        else if(tier.equals(Tier.EXPRESS)) return BigDecimal.valueOf(90);
        else return BigDecimal.valueOf(140);
    }

    public static PricingDetails getNddAspPricingDetails(){
        Map<Tier, DynamicPricingAttributes> dynamicPricingAttributesMap = getDefaultPricingAttributes();
        for(Tier tier : Tier.values()){
            DynamicPricingAttributes dynamicPricingAttributes = new DynamicPricingAttributes(
                    isCommonPriceForAll(tier), getShippingCharges(tier), getAspPricingMap(tier), getCategoryAspPricing(tier),
                    getSalesChannelAspPricing(tier),getShippingChargesPerListing(tier));
            dynamicPricingAttributesMap.put(tier, dynamicPricingAttributes);
        }
        return new PricingDetails(dynamicPricingAttributesMap, getWsrShippingPriceThreshold(),shippingChargeConfiguration);
    }

    public static Boolean isCommonPriceForAll(Tier tier){
        Boolean commonPriceForAll = shippingChargeConfiguration!=null?shippingChargeConfiguration.getCommonPriceForAll(tier):null;
        return commonPriceForAll != null ? commonPriceForAll : false;
    }

    public static BigDecimal getShippingCharges(Tier tier){
        BigDecimal shippingCharge = shippingChargeConfiguration!=null?shippingChargeConfiguration.getBaseShippingCharge(tier):null;
        return shippingCharge != null ? shippingCharge : getDefaultPrice(tier);
    }

    public static Map<BigDecimal, BigDecimal> getAspPricingMap(Tier tier){
        return shippingChargeConfiguration!=null?shippingChargeConfiguration.getGlobalAspShippingMap(tier):null;
    }

    public static Map<String, Map<BigDecimal, BigDecimal>> getCategoryAspPricing(Tier tier){
        return shippingChargeConfiguration!=null?shippingChargeConfiguration.getCategoryAspPricingMap(tier):null;
    }

    public static Map<String, Map<BigDecimal, BigDecimal>> getSalesChannelAspPricing(Tier tier){
        return shippingChargeConfiguration!=null?shippingChargeConfiguration.getSalesChannelAspPricingMap(tier):null;
    }

    public static Map<String, BigDecimal> getShippingChargesPerListing(Tier tier){
        return shippingChargeConfiguration!=null?shippingChargeConfiguration.getShippingChargesPerListing(tier):null;
    }

    public static BigDecimal getWsrShippingPriceThreshold(){
        BigDecimal key = shippingChargeConfiguration!=null?shippingChargeConfiguration.getWsrShippingPriceThreshold():null;
        return key == null ? new BigDecimal(500) : key;
    }

    public static BigDecimal getDefaultPremiumPrice(Tier tier) {
        switch (tier){
            case REGULAR:
            case EXPRESS:return BigDecimal.ZERO;
            case PREMIUM: return BigDecimal.valueOf(70);
            default: return BigDecimal.ZERO;
        }
    }

    public static Map<Tier,BigDecimal> getDefaultF1ShippingCharges(){
        Map<Tier,BigDecimal> premiumShippingPrice = Maps.newHashMap();
        for(Tier tier : Tier.values()){
            premiumShippingPrice.put(tier, getDefaultPremiumPrice(tier));
        }
        return premiumShippingPrice;
    }

    public static Map<Tier,BigDecimal> getF1ShippingCharges() {
        Map<Tier, BigDecimal> premiumShippingPrice = Maps.newHashMap();
        System.out.println("Inside getF1ShippingCharges "+shippingChargeConfiguration);
        if(shippingChargeConfiguration!=null) {
            for (Tier tier : Tier.values()) {
                BigDecimal shippingCharge = shippingChargeConfiguration.getF1ShippingCharge(tier);
                premiumShippingPrice.put(tier, shippingCharge != null ? shippingCharge : getDefaultPremiumPrice(tier));
            }
        }
        return premiumShippingPrice;
    }
}
