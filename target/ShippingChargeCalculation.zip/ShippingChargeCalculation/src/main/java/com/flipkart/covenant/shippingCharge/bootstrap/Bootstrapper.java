package com.flipkart.covenant.shippingCharge.bootstrap;

/**
 * Created by manish.sharan on 13/01/15.
 */
public class Bootstrapper {

    public static void start(){
        Thread initializerThread = new Thread(new Initializer());
        initializerThread.start();
        System.out.println("Thread main");
    }

}
