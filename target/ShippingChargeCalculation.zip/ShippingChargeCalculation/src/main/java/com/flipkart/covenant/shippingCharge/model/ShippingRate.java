package com.flipkart.covenant.shippingCharge.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Created by manish.sharan on 11/01/15.
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ShippingRate {
    private BigDecimal intraCity;
    private BigDecimal intraZone;
    private BigDecimal interZone;

    public static ShippingRate defaultShippingRate() {
        return new ShippingRate(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    public BigDecimal get(ShipmentMovementType shipmentMovementType){
        switch (shipmentMovementType){
            case inter_zone: return this.getInterZone();
            case intra_city: return this.getIntraCity();
            case intra_zone: return this.getIntraZone();
            default : return this.getInterZone();
        }
    }

    public Boolean isInvalid(){
        if(this.getIntraCity()==null||this.getIntraZone()==null||this.getInterZone()==null) return true;
        return false;
    }
}